//! Opt-in current-thread allocation attribution. Disabled during timing samples.
use std::{
    alloc::{GlobalAlloc, Layout, System},
    cell::Cell,
};
thread_local! {
    static ACTIVE: Cell<bool> = const { Cell::new(false) };
    static COUNT: Cell<u64> = const { Cell::new(0) };
    static BYTES: Cell<u64> = const { Cell::new(0) };
    static ORIGINS: std::cell::RefCell<[Option<&'static str>; 128]> = const { std::cell::RefCell::new([None;128]) };
    static TRACE: Cell<bool> = const { Cell::new(false) };
    static ORIGIN_COUNT: Cell<usize> = const { Cell::new(0) };
}
struct Allocator;
fn record(bytes: usize) {
    #[cfg(feature = "table-profile")]
    if bytes == 42000 && TRACE.try_with(Cell::get).unwrap_or(false) {
            let stage = gpui_kit::perf_stats::allocation_probe_stage().unwrap_or("outside");
            let index = ORIGIN_COUNT.with(Cell::get);
            if index < 128 { ORIGINS.with_borrow_mut(|s| s[index] = Some(stage)); }
            ORIGIN_COUNT.with(|n| n.set(index+1));
    }
    if ACTIVE.try_with(Cell::get).unwrap_or(false) {
        let _ = COUNT.try_with(|n| n.set(n.get() + 1));
        let _ = BYTES.try_with(|n| n.set(n.get() + bytes as u64));
    }
}
unsafe impl GlobalAlloc for Allocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        record(layout.size());
        unsafe { System.alloc(layout) }
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        record(layout.size());
        unsafe { System.alloc_zeroed(layout) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) }
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        record(size);
        unsafe { System.realloc(ptr, layout, size) }
    }
}
#[global_allocator]
static ALLOCATOR: Allocator = Allocator;
pub(super) fn measure<T>(f: impl FnOnce() -> T) -> (T, u64, u64) {
    struct Guard;
    impl Drop for Guard {
        fn drop(&mut self) {
            ACTIVE.set(false);
        }
    }
    COUNT.set(0);
    BYTES.set(0);
    ACTIVE.set(true);
    let guard = Guard;
    let result = f();
    drop(guard);
    (result, COUNT.get(), BYTES.get())
}

pub(super) fn trace_start() { ORIGIN_COUNT.set(0); TRACE.set(true); }
pub(super) fn trace_finish() {
    TRACE.set(false);
    ORIGINS.with_borrow(|s| {
        for stage in s.iter().take(ORIGIN_COUNT.with(Cell::get).min(128)) { println!("ALLOCATION_ORIGIN,bytes=42000,stage={}",stage.unwrap()); }
    });
}
