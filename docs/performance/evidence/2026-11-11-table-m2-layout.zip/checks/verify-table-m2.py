import csv, hashlib, json, re, statistics
import math
from pathlib import Path

root = Path(__file__).resolve().parents[1]
directory = root / 'target/table-m2-evidence-02'
identity = json.loads((directory / 'identity.json').read_text())
frames = list(csv.DictReader((directory / 'frames.csv').open()))
assert len(frames) == 12000
expected = None
for ix, run in enumerate(identity['runs']):
    log = directory / f"block-{run['block']}-slot-{run['slot']}-rows-{run['rows']}-attempt-1.txt"
    assert hashlib.sha256(log.read_bytes()).hexdigest() == run['log_sha256']
    samples = re.findall(r'TABLE_FRAME,rows=(\d+),frame=(\d+),ns=(\d+),renders=(\d+)', log.read_text())
    assert len(samples) == 1000
    subset = frames[ix*1000:(ix+1)*1000]
    for sample, frame in zip(samples,subset):
        assert list(map(int,sample)) == [int(frame[k]) for k in ['rows','frame','ns','renders']]
    work = [int(f['renders']) for f in subset]
    if expected is None: expected = work
    assert expected == work
summary = []
for block in range(3):
    runs = [r for r in identity['runs'] if r['block'] == block]
    summary.append({metric: statistics.mean(r[metric] for r in runs if r['rows']==100000)/statistics.mean(r[metric] for r in runs if r['rows']==1000) for metric in ['p50_ns','p95_ns','p99_ns']})
verification = dict(validated_frames=len(frames),renders_min=min(expected),renders_max=max(expected),blocks=summary,medians={},spread={})
# Fixture Medium rows are 2.5rem; 28rem viewport, two overscan rows per side,
# one header track, two frozen data tracks and one footer track. Grouped header
# occupies more height than a data track, so counting it once is conservative.
budget = (math.ceil(28/2.5) + 4 + 1 + 2 + 1) * 12
assert max(expected) <= budget
verification['working_set_budget'] = budget
for count in [1000,100000]:
    runs = [r for r in identity['runs'] if r['rows'] == count]
    verification['medians'][count] = {metric:statistics.median(r[metric] for r in runs) for metric in ['mount_ns','p50_ns','p95_ns','p99_ns']}
    verification['spread'][count] = {metric:(max(r[metric] for r in runs)-min(r[metric] for r in runs))/statistics.median(r[metric] for r in runs) for metric in ['p50_ns','p95_ns','p99_ns']}
(directory / 'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(verification,indent=2))
