import csv, hashlib, json, re, statistics
from pathlib import Path

def verify(d):
    d=Path(d)
    m=json.loads((d/'identity.json').read_text(encoding='utf-8'))
    rows=list(csv.DictReader((d/'frames.csv').open()))
    assert len(rows)==12000 and len(m['runs'])==12
    work=[]
    for run in m['runs']:
        label=f"block-{run['block']}-slot-{run['slot']}-rows-{run['rows']}"
        logs=[p for p in d.glob(label+'-attempt-*.txt') if p.name not in m['discarded']]
        assert len(logs)==1
        log=logs[0]
        assert hashlib.sha256(log.read_bytes()).hexdigest()==run['log_sha256']
        output=log.read_text(encoding='utf-8')
        assert 'test result: ok. 1 passed; 0 failed;' in output
        data=[r for r in rows if int(r['block'])==run['block'] and int(r['slot'])==run['slot']]
        assert [int(r['frame']) for r in data]==list(range(1000))
        assert all(0<int(r['renders'])<=377 and int(r['ns'])>0 and int(r['rows'])==run['rows'] for r in data)
        work.append([int(r['renders']) for r in data])
        values=sorted(int(r['ns']) for r in data)
        for name,f in [('p50_ns',.5),('p95_ns',.95),('p99_ns',.99)]:
            assert values[int((len(values)-1)*f)]==run[name]
        alloc=re.findall(r'TABLE_ALLOC,rows=(\d+),sample=(\d+),allocations=(\d+),bytes=(\d+)',output)
        assert len(alloc)==10 and [list(a) for a in alloc]==run['allocations']
    assert all(w==work[0] for w in work), 'size comparison must perform the same cell work at each trace point'
    return dict(frames=len(rows),independent_blocks=3,workset_min=min(work[0]),workset_max=max(work[0]),same_workset_each_frame=True,discarded=m['discarded'])

if __name__=='__main__':
    import sys
    print(json.dumps(verify(sys.argv[1]),indent=2))
