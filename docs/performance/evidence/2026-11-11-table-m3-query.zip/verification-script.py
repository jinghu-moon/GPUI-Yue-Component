import csv, hashlib, json, statistics
from pathlib import Path

def verify(directory):
    directory=Path(directory)
    metadata=json.loads((directory/'metadata.json').read_text())
    rows=list(csv.DictReader((directory/'queries.csv').open()))
    assert len(rows)==198
    expected=[]
    for mode in range(11):
        expected.append(sum(1 for i in range(250000) if {1:i%19==0,2:i%3!=0,3:4<=i%19<=9 and i%3!=0,5:i%4==0,6:2<=i%12<=4,7:i%5 in (0,3),8:False}.get(mode,True)))
    for run in metadata['runs']:
        raw=(directory/run['log']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==run['sha256']
        text=raw.decode('utf-8')
        assert 'test result: ok. 1 passed; 0 failed;' in text
        observed=[(int(r['mode']),int(r['sample'])) for r in rows if int(r['run'])==run['run']]
        assert observed==[(mode,sample) for mode in range(11) for sample in range(6)]
    for row in rows:
        mode=int(row['mode'])
        assert int(row['total'])==expected[mode]
        assert int(row['rows'])==(37 if mode==10 else expected[mode])
        assert all(int(row[key])>0 for key in ['query','validate','filter','sort','projection','accept'])
        assert sum(int(row[key]) for key in ['validate','filter','sort','projection'])<=int(row['query'])
    for mode in range(11):
        for field,value in metadata['repeated_medians_ns'][str(mode)].items():
            assert statistics.median(int(r[field]) for r in rows if int(r['mode'])==mode and int(r['sample'])>0)==value
    return dict(samples=len(rows),total_oracle=expected,accepted_runs=3,discarded=metadata['discarded'])

if __name__=='__main__':
    import sys
    print(json.dumps(verify(sys.argv[1]),indent=2))
