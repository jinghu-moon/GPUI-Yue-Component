"""Independent evidence validation; pass an extracted evidence archive directory."""
import csv
import hashlib
import json
from pathlib import Path
import re
import sys


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def verify(root):
    root=Path(root)
    a=json.loads((root/'tb02/identity.json').read_text(encoding='utf-8'))
    b=json.loads((root/'tb05/identity.json').read_text(encoding='utf-8'))
    assert a['source_sha256']==b['source_sha256']
    assert a['executable_sha256']==b['executable_sha256']
    record=root/'checks/table-m6-release-build.jsonl'
    assert sha(record)==a['build_record_sha256']==b['build_record_sha256']
    builds=[json.loads(line) for line in record.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert any(r.get('target',{}).get('name')=='table' and r.get('executable') and r['profile']['opt_level']=='3' and r['profile']['test'] for r in builds)
    source=json.loads((root/'source-manifest.json').read_text(encoding='utf-8'))
    h=hashlib.sha256()
    for entry in source['sampled']:
        path=root/'source'/entry['path']
        assert sha(path)==entry['sha256']
        h.update(entry['path'].encode())
        h.update(path.read_bytes())
    assert h.hexdigest()==a['source_sha256']
    for entry in source['auxiliary']:
        assert sha(root/'source'/entry['path'])==entry['sha256']
    assert sha(root/'source/tools/sample-table-churn.py')==b['runner_sha256']
    rows=list(csv.DictReader((root/'tb02/frames.csv').open(encoding='utf-8')))
    assert len(rows)==12000 and len(a['runs'])==12
    work=[]
    for run in a['runs']:
        label=f"block-{run['block']}-slot-{run['slot']}-rows-{run['rows']}"
        logs=[p for p in (root/'tb02').glob(label+'-attempt-*.txt') if p.name not in a['discarded']]
        assert len(logs)==1 and sha(logs[0])==run['log_sha256']
        output=logs[0].read_text(encoding='utf-8')
        assert len(re.findall(r'test cells::tb02_cells_frame_sample \.\.\.',output))==1
        assert len(re.findall(r'^ok$',output,re.M))==1
        assert 'test result: ok. 1 passed; 0 failed;' in output
        data=[r for r in rows if int(r['block'])==run['block'] and int(r['slot'])==run['slot']]
        assert [int(r['frame']) for r in data]==list(range(1000))
        raw=re.findall(r'TABLE_FRAME,rows=(\d+),frame=(\d+),ns=(\d+),renders=(\d+)',output)
        assert raw==[(r['rows'],r['frame'],r['ns'],r['renders']) for r in data]
        assert all(0<int(r['renders'])<=377 and int(r['ns'])>0 and int(r['rows'])==run['rows'] for r in data)
        work.append([int(r['renders']) for r in data])
        values=sorted(int(r['ns']) for r in data)
        for name,f in [('p50_ns',.5),('p95_ns',.95),('p99_ns',.99)]:
            assert values[int((len(values)-1)*f)]==run[name]
        alloc=re.findall(r'TABLE_ALLOC,rows=(\d+),sample=(\d+),allocations=(\d+),bytes=(\d+)',output)
        assert len(alloc)==10 and [list(v) for v in alloc]==run['allocations']
    assert all(w==work[0] for w in work)
    rows=list(csv.DictReader((root/'tb05/samples.csv').open(encoding='utf-8')))
    assert len(rows)==600 and len(b['runs'])==6
    for run in b['runs']:
        log=root/'tb05'/run['log']
        assert log.name not in b['discarded'] and sha(log)==run['log_sha256']
        output=log.read_text(encoding='utf-8')
        assert output.count('test churn::tb05_snapshot_churn ...')==1
        assert len(re.findall(r'^ok$',output,re.M))==1 and 'test result: ok. 1 passed; 0 failed;' in output
        data=[r for r in rows if int(r['block'])==run['block'] and int(r['measured'])==run['measured']]
        assert [int(r['step']) for r in data]==list(range(100))
        raw=re.findall(r'TABLE_CHURN,measured=(\d+),step=(\d+),prepare_ns=(\d+),accept_ns=(\d+),draw_effects_ns=(\d+),historical_sources=(\d+)',output)
        assert raw==[(r['measured'],r['step'],r['prepare_ns'],r['accept_ns'],r['draw_effects_ns'],r['historical_sources']) for r in data]
        assert all(int(r['historical_sources'])==0 and all(int(r[f])>0 for f in ['prepare_ns','accept_ns','draw_effects_ns']) for r in data)
    for family,m in [('tb02',a),('tb05',b)]:
        assert all((root/family/name).exists() for name in m['discarded'])
    trace=(root/'checks/table-m6-w2-release.txt').read_text(encoding='utf-8-sig')
    assert 'TABLE_TRACE,groups=200,operations=800,axes=2,coverage=ok' in trace
    assert 'test result: ok. 1 passed; 0 failed;' in trace
    return dict(tb02_frames=12000,workset=[min(work[0]),max(work[0])],per_frame_work_identical=True,tb05_publications=600,historical_sources=0,w2_operations=800,source_sha256=a['source_sha256'],discarded={'tb02':a['discarded'],'tb05':b['discarded']})

if __name__=='__main__':
    print(json.dumps(verify(sys.argv[1]),indent=2))
